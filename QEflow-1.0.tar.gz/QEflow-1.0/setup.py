from setuptools import setup, find_packages

setup(
    name='QEflow',  
    version='1.0',  
    packages=find_packages(),  
    install_requires=[
        'pymatgen',
        'numpy',
        'pandas',
    ],
    include_package_data=True,
    description='A high-throughput toolkit for QE',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    author='Jiahao Wu',
    author_email='wogaho1999@gmail.com',
    url='https://github.com/JiahaoWu666/QEflow', 
)



